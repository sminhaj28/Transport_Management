package com.transport.ui;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class AddressJFrame extends JPanel {

	private JPanel m_contentPane;
	private com.transport.model.Address address = new com.transport.model.Address();
	private JTextArea addressLine1JTextArea;
	private JTextArea addressLine2JTextArea;
	private JTextField cityJTextField;
	private JTextField countryJTextField;
	private JTextField stateJTextField;
	private JTextField pinJTextField;

			
	

	/**
	 * Create the frame.
	 */
	public AddressJFrame() {
		setBounds(100, 100, 450, 300);
		m_contentPane = new JPanel();
		//
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 0, 0, 0 };
		gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, 1.0, 1.0E-4 };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				1.0E-4 };
		m_contentPane.setLayout(gridBagLayout);

		JLabel addressLine1Label = new JLabel("AddressLine1:");
		GridBagConstraints labelGbc_0 = new GridBagConstraints();
		labelGbc_0.insets = new Insets(5, 5, 5, 5);
		labelGbc_0.gridx = 0;
		labelGbc_0.gridy = 0;
		m_contentPane.add(addressLine1Label, labelGbc_0);

		addressLine1JTextArea = new JTextArea();
		GridBagConstraints componentGbc_0 = new GridBagConstraints();
		componentGbc_0.insets = new Insets(5, 0, 5, 5);
		componentGbc_0.fill = GridBagConstraints.HORIZONTAL;
		componentGbc_0.gridx = 1;
		componentGbc_0.gridy = 0;
		m_contentPane.add(addressLine1JTextArea, componentGbc_0);

		JLabel addressLine2Label = new JLabel("AddressLine2:");
		GridBagConstraints labelGbc_1 = new GridBagConstraints();
		labelGbc_1.insets = new Insets(5, 5, 5, 5);
		labelGbc_1.gridx = 0;
		labelGbc_1.gridy = 1;
		m_contentPane.add(addressLine2Label, labelGbc_1);

		addressLine2JTextArea = new JTextArea();
		GridBagConstraints componentGbc_1 = new GridBagConstraints();
		componentGbc_1.insets = new Insets(5, 0, 5, 5);
		componentGbc_1.fill = GridBagConstraints.HORIZONTAL;
		componentGbc_1.gridx = 1;
		componentGbc_1.gridy = 1;
		m_contentPane.add(addressLine2JTextArea, componentGbc_1);

		JLabel cityLabel = new JLabel("City:");
		GridBagConstraints labelGbc_2 = new GridBagConstraints();
		labelGbc_2.insets = new Insets(5, 5, 5, 5);
		labelGbc_2.gridx = 0;
		labelGbc_2.gridy = 2;
		m_contentPane.add(cityLabel, labelGbc_2);

		cityJTextField = new JTextField();
		GridBagConstraints componentGbc_2 = new GridBagConstraints();
		componentGbc_2.insets = new Insets(5, 0, 5, 5);
		componentGbc_2.fill = GridBagConstraints.HORIZONTAL;
		componentGbc_2.gridx = 1;
		componentGbc_2.gridy = 2;
		m_contentPane.add(cityJTextField, componentGbc_2);

		JLabel countryLabel = new JLabel("Country:");
		GridBagConstraints labelGbc_3 = new GridBagConstraints();
		labelGbc_3.insets = new Insets(5, 5, 5, 5);
		labelGbc_3.gridx = 0;
		labelGbc_3.gridy = 3;
		m_contentPane.add(countryLabel, labelGbc_3);

		countryJTextField = new JTextField();
		GridBagConstraints componentGbc_3 = new GridBagConstraints();
		componentGbc_3.insets = new Insets(5, 0, 5, 5);
		componentGbc_3.fill = GridBagConstraints.HORIZONTAL;
		componentGbc_3.gridx = 1;
		componentGbc_3.gridy = 3;
		m_contentPane.add(countryJTextField, componentGbc_3);

		JLabel stateLabel = new JLabel("State:");
		GridBagConstraints labelGbc_4 = new GridBagConstraints();
		labelGbc_4.insets = new Insets(5, 5, 5, 5);
		labelGbc_4.gridx = 0;
		labelGbc_4.gridy = 4;
		m_contentPane.add(stateLabel, labelGbc_4);

		stateJTextField = new JTextField();
		GridBagConstraints componentGbc_4 = new GridBagConstraints();
		componentGbc_4.insets = new Insets(5, 0, 5, 5);
		componentGbc_4.fill = GridBagConstraints.HORIZONTAL;
		componentGbc_4.gridx = 1;
		componentGbc_4.gridy = 4;
		m_contentPane.add(stateJTextField, componentGbc_4);

		JLabel pinLabel = new JLabel("Pin:");
		GridBagConstraints labelGbc_5 = new GridBagConstraints();
		labelGbc_5.insets = new Insets(5, 5, 5, 5);
		labelGbc_5.gridx = 0;
		labelGbc_5.gridy = 5;
		m_contentPane.add(pinLabel, labelGbc_5);

		pinJTextField = new JTextField();
		GridBagConstraints componentGbc_5 = new GridBagConstraints();
		componentGbc_5.insets = new Insets(5, 0, 5, 5);
		componentGbc_5.fill = GridBagConstraints.HORIZONTAL;
		componentGbc_5.gridx = 1;
		componentGbc_5.gridy = 5;
		m_contentPane.add(pinJTextField, componentGbc_5);

		if (address != null) {
		}
	}

	public com.transport.model.Address getAddress() {
		return address;
	}

	public void setAddress(com.transport.model.Address newAddress) {
		setAddress(newAddress, true);
	}

	public void setAddress(com.transport.model.Address newAddress,
			boolean update) {
		address = newAddress;
		if (update) {

		}
	}

}
