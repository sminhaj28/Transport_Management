package com.transport.model;
public class Vehicle {
	private String name;
	private String type;
	private String company;
	private String weight;
	private String fuelType;
	
	public Vehicle(String name, String type, String company, String weight,
			String fuelType) {
		super();
		this.name = name;
		this.type = type;
		this.company = company;
		this.weight = weight;
		this.fuelType = fuelType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	
}
