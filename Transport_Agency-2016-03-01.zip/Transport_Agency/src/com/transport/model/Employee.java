package com.transport.model;

import java.util.Date;

public class Employee extends Person{
	private String salary;
	private String role;
	private Address address;
	/**
	 * Date of joining of employee in the organization
	 */
	private Date doj;
	private String bloodGroup;
	private String education;

}
