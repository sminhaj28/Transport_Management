package com.transport.model;

import java.util.ArrayList;

/**
 * Transport agency is entity who runs transport service
 * 
 * @author Minhaj
 *
 */
public class TransportAgency {
	private String name;
	private Address address;
	

	private ArrayList<Employee> employees;
	private ArrayList<Vehicle> vehicles;
	private ArrayList<Customer> customers;

}
