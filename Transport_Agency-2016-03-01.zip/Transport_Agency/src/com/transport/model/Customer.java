package com.transport.model;

public class Customer {
	private String name;
	private Address address;
	private Person person;
	public Customer(String name, Address address, Person person) {
		super();
		this.name = name;
		this.address = address;
		this.person = person;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}

}
