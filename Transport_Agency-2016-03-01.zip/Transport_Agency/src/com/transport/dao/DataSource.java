package com.transport.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DataSource {
	private static Statement statement;
	private static Connection connection;
	
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Transport", "root",
					"root");
		} catch (Exception e) {
			System.out.println("Driver not found | fail to connect to database. Please do the required configuration...");
			System.exit(0);
		}
	}
	
	public static Statement getStatement(){
		if(statement == null){
			try {
				statement = connection.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return statement;
}
}