package com.transport.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.transport.model.Address;

public class AddressDao {

	public static boolean save(Address address) {
		boolean result = false;
		Statement statement = DataSource.getStatement();
		try {
			int executeUpdate = statement
					.executeUpdate("insert into address (addressLine1, addressLine2,city,state,country,pin) values("
							+ address.getAddressLine1()
							+ "','"
							+ address.getAddressLine2()
							+ "','"
							+ address.getCity()
							+ "','"
							+ address.getState()
							+ ", '"
							+ address.getCountry()
							+ "','"
							+ address.getPin() + "')");

			result = executeUpdate > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static List<Address> findAll() {
		Statement statement = DataSource.getStatement();
		List<Address> addresses = new ArrayList<Address>();
		try {
			ResultSet resultSet = statement
					.executeQuery("SELECT * from student");
			while (resultSet.next()) {

				String addressLine1 = resultSet.getString("addressLine1");
				String addressLine2 = resultSet.getString("addressLine2");
				String city = resultSet.getString("city");
				String state = resultSet.getString("state");
				String country = resultSet.getString("country");
				String pin = resultSet.getString("pin");
				Address address = new Address();
				addresses.add(address);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return addresses;
	}

	public static int update(Address address) {

		return 0;
	}

	public static boolean delete(Address address) {

		return false;
	}

}
